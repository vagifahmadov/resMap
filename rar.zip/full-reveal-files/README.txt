Reveal - Responsive Business Listing HTML Template
--------------------------

Thank you for buying the Listly - Business Listing HTML Template!

You will find the help files inside the "_documentation" folder.

If you need further assistance feel free to contact Themezhub on the profile page: https://Themezhub.net/contact/

If you like this template, please consider giving it a comment and/or a rating!

Notice: This theme was not developed to serve as a content publishing theme. It lacks post styling, commenting features, proper SEO coding for posts and many other features. Its only functionality was meant to be either a Mobile App Template.

Thank you once again,

The Themezhub team

Version: 1.0
Release date: 5 Feb 2021